# CREATIVE//BOUNTY

> **Demand before generation.**

An autonomous generative-media opportunity agent that starts from paid demand, proves AI use is permitted, gates spend, generates only after qualification, and preserves an auditable evidence trail.

## The inversion
Most generative-media apps begin with a prompt and hope the output becomes valuable. CREATIVE//BOUNTY asks first:

> **Who already wants the media, are we allowed to generate it, and is generation economically authorized?**

Only then does the media pipeline unlock.

## Hackathon architecture

```text
PAID DEMAND
    ↓
RIGHTS GATE ───→ REVIEW / REJECT
    ↓ PASS
ECONOMIC GATE
    ↓
HARD BUDGET AUTHORIZATION
    ↓
GENBLAZE → evaluate → reject/retry/fallback
    ↓
BACKBLAZE B2
    ↓
asset + manifest + decisions + evidence + outcome
```

The LIVE adapter follows the current Backblaze Genblaze primitives: `Pipeline`, provider adapters, `StepCache`, model fallbacks, `ObjectStorageSink`, `S3StorageBackend.for_backblaze(...)`, SHA-256 assets and native provenance manifests.

## Constitution
1. **No user capital.**
2. **No generation without qualified demand.**
3. **No AI without explicit permission.** Ambiguity becomes `REVIEW`.
4. **No fake revenue.** Advertised reward never counts as realized revenue.
5. **Prove every decision and asset.**

## What works now
- deterministic SAMPLE end-to-end pipeline;
- explicit `PASS / REVIEW / REJECT` rights engine;
- deterministic economic prioritization;
- hard paid-generation budget invariant;
- production-plan compiler;
- append-only economic ledger;
- append-only opportunity event log;
- reject → retry → accept SAMPLE loop;
- local SHA-256 tamper checks explicitly distinguished from native Genblaze provenance;
- B2/Genblaze LIVE sink and provider adapter;
- gated LIVE service that cannot call a provider before rights/economics/budget preflight;
- machine-readable `/api/status`, `/api/opportunities`, `/api/evidence/{id}`;
- polished judge-facing FastAPI UI;
- CI, Dockerfile and submission validator.

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate
pip install -e '.[dev]'
uvicorn creative_bounty.app:app --reload
```
Open `http://127.0.0.1:8000`.

The repository ships in **SAMPLE mode**. Included opportunities and generated media are clearly labeled SAMPLE.

## Tests
```bash
pytest -q
python scripts/validate_submission.py
```

## LIVE integration
```bash
pip install -e '.[genblaze,dev]'
cp .env.example .env
```
Configure B2 and one legitimate provider. No provider is called automatically.

Relevant code:
- `src/creative_bounty/orchestrator.py` — fail-closed preflight
- `src/creative_bounty/genblaze_adapter.py` — current Genblaze/B2 primitives
- `src/creative_bounty/live_service.py` — gated real execution
- `src/creative_bounty/provenance.py` — native Genblaze proof extraction

See `docs/live-checklist.md`.

## Evidence layout
```text
artifacts/evidence/{opportunity-id}/
  source/opportunity.json
  eligibility.json
  economics.json
  production-plan.json
  events.jsonl
  generations/
    attempt-001/       # SAMPLE path
      asset.png
      evaluation.json
      manifest.json    # explicitly SAMPLE, not Genblaze
      integrity.json
    live-001/          # LIVE path
      genblaze-proof.json
  submission/package.json
  run.json
```

## Truth protocol
The project deliberately keeps these concepts separate:

**reward ≠ revenue** · **sample hash ≠ Genblaze provenance** · **qualified ≠ won** · **authorization ceiling ≠ actual cost**

See `docs/truth-protocol.md`.

## Honest current status
**Working without credentials:** complete SAMPLE control plane, UI, audit APIs, rights/economic/budget gates, evidence tree and tests.

**LIVE code is implemented but not falsely claimed as executed here:** it still needs user-supplied B2/provider credentials and one legitimate provider run. No marketplace sale, customer, revenue or real provider output is fabricated.

## Judge hook
> “Most AI media apps ask what you want to generate. CREATIVE//BOUNTY asks who already wants the media, whether AI is actually allowed, and whether generation deserves to spend a cent.”

## Real opportunity radar (v0.3)

The demo now includes **LIVE-CURATED** current opportunities alongside deterministic SAMPLE fixtures. This is deliberately not called live scraping: each current opportunity has an official URL, verification timestamp, structured facts, and a SHA-256 source snapshot.

Two current examples demonstrate the decision engine:

- **Future Vision XPRIZE 2026** — generative AI is explicitly allowed, but exclusivity/finals obligations force human review before pursuit.
- **Runway Another Big Ad Contest — Volume II** — AI is allowed and the prize is large, but an active paid Runway plan is mandatory, so the zero-capital policy hard-stops the opportunity.

This is the point of CREATIVE//BOUNTY: **large advertised reward does not automatically mean pursue**.

```bash
PYTHONPATH=src python -m creative_bounty scan
```

The radar keeps currencies separate; it never sums USD and EUR into a fake "total opportunity value".

### Zero-cost live preflight

Before any real provider call:

```bash
PYTHONPATH=src python scripts/live_preflight.py
```

The preflight writes `artifacts/live-preflight.json`, reports only whether credentials are present, never echoes secrets, and never starts generation.

### Current validation

```text
21 passed
submission validation: PASS
```

## Evidence receipt

Every completed run now produces `audit-receipt.json`, a portable SHA-256 receipt over the complete evidence bundle (source, rights, economics, attempts, events and submission metadata). It can be independently checked with:

```bash
python scripts/verify_evidence.py artifacts/evidence/<opportunity-id>
```

The receipt is deliberately labeled as CREATIVE//BOUNTY integrity metadata: it is **not** a Genblaze provenance manifest and **not** a blockchain proof. LIVE media additionally retains native Genblaze manifest verification.

## B2 is a governance layer

The storage design separates durable `evidence/` from disposable `intermediates/`, exposes lifecycle intent, and supports an Object Lock intent flag. Remote Object Lock is never claimed active until verified. See `docs/b2-governance.md`.

## v5 — judgeability and fail-closed lifecycle

v5 adds three competition-facing controls:

1. **Lifecycle state machine.** An opportunity cannot jump from `DISCOVERED` to `GENERATING`; rights, economics and budget authorization must occur in order.
2. **Decision Certificate.** `/api/decision-certificate/{id}` returns a portable, tamper-evident explanation of `PURSUE / REVIEW / REJECT`, including reward currency, rights evidence, economic score, available budget and explicit truth flags.
3. **Judge Pack.** `make judge-pack` runs tests + submission validation and creates a compact ZIP containing the architecture, judging map, truth protocol, demo script and validation artifacts.

The threat model is documented in `docs/threat-model.md`.
